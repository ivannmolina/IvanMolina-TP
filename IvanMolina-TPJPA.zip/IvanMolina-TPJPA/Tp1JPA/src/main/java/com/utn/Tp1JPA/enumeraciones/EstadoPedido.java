package com.utn.Tp1JPA.enumeraciones;

public enum EstadoPedido {
    INICIADO,
    PREPARACION,
    ENTREGADO
}
