package com.utn.Tp1JPA.enumeraciones;

public enum TipoEnvio {
    DELIVERY,
    RETIRA
}
