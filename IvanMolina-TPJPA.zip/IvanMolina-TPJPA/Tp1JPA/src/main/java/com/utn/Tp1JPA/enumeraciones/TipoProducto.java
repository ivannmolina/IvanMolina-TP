package com.utn.Tp1JPA.enumeraciones;

public enum TipoProducto {
    MANUFACTURADO,
    INSUMO
}
