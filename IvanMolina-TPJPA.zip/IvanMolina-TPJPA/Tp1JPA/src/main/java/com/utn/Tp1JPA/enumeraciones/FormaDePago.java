package com.utn.Tp1JPA.enumeraciones;

public enum FormaDePago {
    EFECTIVO,
    TRANSFERENCIA,
    TARJETA
}
